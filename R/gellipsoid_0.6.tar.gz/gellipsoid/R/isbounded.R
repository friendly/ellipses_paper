# Properties of ellipsoids

isbounded <-
function(x,...) UseMethod('isbounded')

isbounded.gell <- function(x,...) all( is.finite(x$d))

isfat <- function(x,...) UseMethod('isfat')
isfat.gell <- function(x,...) all( x$d > 0)

isflat <- function(x,...) !isfat(x,...)
isunbounded <- function(x,...) !isbounded(x,...)

