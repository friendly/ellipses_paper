UD <-
function(x) {
  # SVD modified to return U, and D extended with 0's
  x <- as.matrix(x)
  ret <- svd(x,nu=nrow(x),nv=0)[c('u','d')]
  if( length(ret$d) < nrow(x)) ret$d <-
      c(ret$d, rep(0,length.out=nrow(x)-length(ret$d)))
  ret
}

