# draw basis vectors in an rgl scene

basis3d <- function(matrix=diag(3), origin=c(0,0,0), scale=1, 
		draw=TRUE, label=draw, texts=colnames(basis), lwd=3, cex=2, ...) {
	basis <- translate3d(scale*matrix, origin[1], origin[2], origin[3])
	basis <- rbind(origin, basis[1,], origin, basis[2,], origin, basis[3,])
	colnames(basis) <- unlist(strsplit("xyz", ""))
	if(draw) segments3d(basis, lwd=lwd, ...)
	if(label) text3d(scale*.1 + basis[c(2,4,6),], texts=texts, cex=cex, ...)
	invisible(basis)
}
