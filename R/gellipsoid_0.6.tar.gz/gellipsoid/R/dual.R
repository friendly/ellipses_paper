dual <-
function(x,...) UseMethod("dual")

dual.gell <-
function(x,...) {
  n <- length(x$d)
  x$d <- rev(1/x$d)
  x$u <- x$u[,n:1]
  x  
}
