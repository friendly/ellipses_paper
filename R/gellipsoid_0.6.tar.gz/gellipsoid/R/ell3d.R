ell3d <- function(x, ...) UseMethod("ell3d")

ell3d.default <- function(x, shape, radius=1, segments = 40, shade=TRUE, wire=FALSE, ...) {
  E <- ellipsoid(x, shape, radius=radius, segments = segments)
  if (shade) E <- shade3d(E, ...)
  if (wire)  E <- wire3d(E, ...)
  invisible(E)
}

ell3d.gell <- function( x, length = 10, sides = 30, segments = 40, shade=TRUE, wire=FALSE, ...){
  
  if ( isbounded(x) ) { # proper (fat bounded) ellipsoid or bounded flat
        E <- ellipsoid( 
          center = x$center, 
          shape = tcrossprod( x$u %*% diag(x$d)), radius = 1, segments = segments)

  }
  else if (all(signature(x) == c(2,0,1))) { # cylinder
    e1 <- e2 <- center <- matrix(0, nrow=2*length + 1, ncol =3)
    center[,1] <- -length:length
    e1[,1] <- 1
    e2[,2] <- 1
    # unit cylinder
    ucyl <- cylinder3d(center = center, e1 = e1, e2 = e2, radius = 1, sides = sides)
    d <- x$d
    d[is.infinite(d)] <- 1
    mat <- x$u %*% diag(d)
    E <- rotate3d(ucyl, matrix = t(mat) )
    E <- translate3d(E, x$center[1],x$center[2],x$center[3])
  } else stop(paste("Signature", signature(x), "not yet implemented"))
  if (shade) shade3d(E, ...)
  if (wire)  wire3d(E, ...)
  invisible(E)                                          
}

