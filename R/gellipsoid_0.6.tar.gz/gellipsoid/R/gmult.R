gmult <-
function( A , G , epsfac = 2){
  # Linear transformation of an ellipsoid
  gell( A = A %*% G$u, d = G$d, epsfac = epsfac)
}

