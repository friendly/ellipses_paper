##
# Functions to save and restore the par3d parameters for an rgl scene
#
# Use to make a manually manipulated rgl view reproducible
# Within an R session, simply par3d.save the view(s) to named objects
# Across sessions, use the filename arguement to save these to .rds files

par3d.save <-
function (params = c("userMatrix", "scale", "zoom", "FOV"), filename, dev = rgl.cur()) 
{
    parms <- par3d(params)
    if (length(params) == 1) {
        parms <- list(parms)
        names(parms) <- params
    }
    if(!missing(filename)) saveRDS(parms, file=filename)
    invisible(parms)
}

par3d.restore <-
function (parms, filename) {
    if(!missing(filename)) parms <- readRDS(file=filename)
    par3d(parms)
}
 