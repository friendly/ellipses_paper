signature <-
function(G) {
  # the signature of an ellipsoid: 
  # number of positive singular values, zero singular values and Inf singular values
  d <- G$d
  c(pos = sum( is.finite(d) & d > 0), zero = sum( d==0), inf = sum(!is.finite(d))) 
}

